package Models;

/**
 *
 * @author Imasha
 */
public class EMPLOYEE {

    public static boolean editEMPLOYEE(int ID, String NAME, String MOBILE, String EMAIL, String ADDRESS) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static boolean deleteEMPLOYEE(int ID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private int ID;
    private String NAME;
    private String MOBILE;
    private String EMAIL;
    private String ADDRESS;
    
    public int getID(){
        return ID;
    }
    
    public void setID(int ID){
        this.ID = ID;
    }
    
    public String getNAME(){
        return NAME;
    }
    
    public void setNAME(String NAME){
        this.NAME = NAME;
    }
    
    public String getMOBILE(){
        return MOBILE;
    }
    
    public void setMOBILE(String MOBILE){
        this.MOBILE = MOBILE;
    }
    
    public String getEMAIL(){
        return EMAIL;
    }
    
    public void setEMAIL(String EMAIL){
        this.EMAIL = EMAIL;
    }
    
    public String getADDRESS(){
        return ADDRESS;
    }
    
    public void setADDRESS(String ADDRESS){
        this.ADDRESS = ADDRESS;
    }

    
   
        
}
