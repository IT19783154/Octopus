
package Models;

/**
 *
 * @author User
 */
public class HandlingNewEvents {
    int ID;
    String Name;
    String Manager;
    String Date;
    String Duration;
    String Location;
    Float Cost;
    String RequiredEquipments;

    public HandlingNewEvents(int ID, String Name, String Manager, String Date, String Duration, String Location, Float Cost, String RequiredEquipments) {
        this.ID = ID;
        this.Name = Name;
        this.Manager = Manager;
        this.Date = Date;
        this.Duration = Duration;
        this.Location = Location;
        this.Cost = Cost;
        this.RequiredEquipments = RequiredEquipments;
    }

    public HandlingNewEvents() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public int getID(){
        return ID;
    }
    
    public String getName(){
        return Name;
    }
    
    public String getManager(){
        return Manager;
    }
    
    public String getDate(){
        return Date;
    }
    
    public String getDuration(){
        return Duration;
    }
    
    public String getLocation(){
        return Location;
    }
    
    public Float getCost(){
        return Cost;
    }
    
    public String getRequiredEquipments(){
        return RequiredEquipments;
    }
    
}
