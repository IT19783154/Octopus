package ServiceLayer;

import DatabaseLayer.DatabaseConnection;
import Models.EMPLOYEE;
import Models.Student;

/**
 *
 * @author Imasha
 */
public class EmployeeService {


    public boolean deleteStudent(Student student){
        
        return true;    
    }
}
//    private DatabaseConnection con; 
//    public EmployeeService ()
//    {
//        con=(DatabaseConnection) DatabaseConnection.connect();
//    }
////    public boolean AddEmployee(EMPLOYEE employee) {
////             try
////          {
////             // String query = "insert into Employee "+ "(ID,Name,Mobile,Email,Address)"+"values('"+EMPLOYEE.ID+"',"+EMPLOYEE.NAME+"',"+EMPLOYEE.MOBILE+"',"+EMPLOYEE.EMAIL+"',"+EMPLOYEE.ADDRESS+")";
////                      
////              
////            //  boolean result=con.Execute(query);
////              
////              return true;
////              
////          }catch(Exception sql)
////          {
////              System.out.println("Error "+sql.getMessage());
////                
////              
////          } 
                      
                      
                    
              
          
        
           
            
    
    

