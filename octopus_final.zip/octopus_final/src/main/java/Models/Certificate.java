package Models;

public class Certificate {

    private String CetificateName;
    private String CetificateId;
    private String CetificateFee;
    private String Cetificateduration;
    private String EntityRequirement;
    private String DegreeDays;

    public Certificate(String CetificateName, String CetificateId, String CetificateFee, String Cetificateduration,
            String EntityRequirement, String DegreeDays) {

        this.CetificateName = CetificateName;
        this.CetificateId = CetificateId;
        this.CetificateFee = CetificateFee;
        this.Cetificateduration = Cetificateduration;
        this.EntityRequirement = EntityRequirement;
        this.DegreeDays = DegreeDays;
        

    }
    @Override
    public String toString()
    {
        return "Cetificate Name"+this.CetificateName+"Cetificate Id"+this.CetificateId+"Cetificate Fee"+this.CetificateFee+
                " Cetificate duration"+this.Cetificateduration+"Entity Requirement"+this.EntityRequirement+"DegreeDays"+
                this.DegreeDays;
    }

}