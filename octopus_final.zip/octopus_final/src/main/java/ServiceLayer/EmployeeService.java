package ServiceLayer;

import DatabaseLayer.DatabaseConnection;
import Models.EMPLOYEE;

/**
 *
 * @author Imasha
 */
public class EmployeeService {
    private DatabaseConnection con; 
    public EmployeeService ()
    {
        con=DatabaseConnection.getSingleConnection();
    }
    public boolean AddEmployee(EMPLOYEE employee) 
    {
    try
          {
              String query = "insert into Employee "+ "(ID,Name,Mobile,Email,Address)"+"values('"+EMPLOYEE.ID+"',"+EMPLOYEE.NAME+"',"+EMPLOYEE.MOBILE+"',"+EMPLOYEE.EMAIL+"',"+EMPLOYEE.ADDRESS+")";
                      
              
              boolean result=con.Execute(query);
              
              return result;
              
          }catch(Exception sql)
          {
              System.out.println("Error "+sql.getMessage());
              
            
              
          }   
                      
                      
                      
              
          
        
           
            
    
    

